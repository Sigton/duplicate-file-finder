import sqlite3
import time

import fileInfo


PROCESS_OUTPUT_FREQ = 500


class DBConnection(object):

    def __init__(self, scan_dir, path=None):

        if path is None:
            self.name = "{}.db".format(scan_dir.split("/")[-1].replace("_", "-").upper())
            self.db = sqlite3.connect("db/{}".format(self.name))
            self.cursor = self.db.cursor()

            self.cursor.execute("""CREATE TABLE files(
                            id INTEGER PRIMARY KEY, name TEXT, size INTEGER, path TEXT,
                            content INTEGER, modified_date FLOAT)
                            """)

            self.cursor.execute("""CREATE TABLE originals(
                            original_id INTEGER PRIMARY KEY, name TEXT, path TEXT, content INTEGER,
                            size INTEGER, modified_date FLOAT)
                            """)

            self.cursor.execute("""CREATE TABLE duplicates(
                            duplicate_id INTEGER PRIMARY KEY, name TEXT, path TEXT, modified_date FLOAT,
                            content INTEGER,original_id INT,
                            FOREIGN KEY (original_id) REFERENCES originals(original_id))""")

            self.db.commit()

            self.requires_init_scan = False
        else:
            self.name = path.split("/")[-1].upper()
            self.db = sqlite3.connect("db/{}.db".format(self.name))
            self.cursor = self.db.cursor()
            self.requires_init_scan = True

    def write_file_info(self, file_objects):

        for obj in file_objects:
            self.cursor.execute('''INSERT INTO files(id, name, size, path, content, modified_date)
            VALUES(?,?,?,?,?,?)''', (obj.file_id, obj.name, obj.size, obj.path, obj.content, obj.modified_date))

        self.db.commit()

    def init_scan(self):

        self.cursor.execute("DROP TABLE originals")
        self.cursor.execute("DROP TABLE duplicates")

        self.cursor.execute("""CREATE TABLE originals(
                                    original_id INTEGER PRIMARY KEY, name TEXT, path TEXT, content INTEGER,
                                    size INTEGER, modified_date FLOAT)
                                    """)

        self.cursor.execute("""CREATE TABLE duplicates(
                                    duplicate_id INTEGER PRIMARY KEY, name TEXT, path TEXT, modified_date FLOAT,
                                    content INTEGER,original_id INT,
                                    FOREIGN KEY (original_id) REFERENCES originals(original_id))""")

    def duplicate_check(self):

        if self.requires_init_scan:
            self.init_scan()

        self.cursor.execute("""SELECT id, content FROM files""")
        files = self.cursor.fetchall()

        processed = set()
        for file in files:
            if len(processed) % PROCESS_OUTPUT_FREQ == 0:
                print("{} files processed.".format(len(processed)))

            if file[0] in processed:
                continue

            self.cursor.execute(
                """SELECT id, name, path, modified_date, content, size
                FROM files WHERE content=? ORDER BY modified_date""",
                (file[1],))

            original = self.cursor.fetchone()
            duplicates = self.cursor.fetchall()

            original_id = original[0]

            if original_id in processed:
                processed.add(file[0])
                continue

            self.cursor.execute("""INSERT INTO originals(original_id, name, path, content, size, modified_date)
                                            VALUES (?,?,?,?,?,?)""",
                                (original_id, original[1], original[2],
                                 original[4], original[5], original[3]))
            for d in duplicates:
                self.cursor.execute("""INSERT INTO duplicates(original_id, name, path, modified_date)
                                                        VALUES (?,?,?,?)""",
                                    (original_id, d[1], d[2], d[3]))

            processed.add(original_id)

        self.db.commit()

    def duplicate_check2(self):

        if self.requires_init_scan:
            self.init_scan()

        self.cursor.execute("SELECT content FROM files")

        self.db.commit()

    def get_duplicate_count(self):

        self.cursor.execute("""SELECT COUNT(duplicate_id) FROM duplicates""")
        return self.cursor.fetchone()[0]

    def get_file_count(self):

        self.cursor.execute("SELECT count(id) FROM files")
        return self.cursor.fetchone()[0]

    def foo(self):

        self.cursor.execute("""
        SELECT duplicates.duplicate_id, duplicates.original_id, duplicates.path, originals.path
        FROM duplicates, originals
        WHERE duplicates.original_id = originals.original_id
        ORDER BY originals.size DESC
        """)

        return self.cursor.fetchall()

    def close(self):

        self.db.close()
