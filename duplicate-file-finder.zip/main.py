import fileInfo
import dbManager
import time


def main():

    dir_to_check = input("Enter directory to scan: ")
    db = dbManager.DBConnection(dir_to_check)
    time_since_scan = db.check_existing_scan()

    if time_since_scan is not None:
        print("\n '{}' was scanned {} seconds ago. Do you wish to use that scan? [0] No [1] Yes")

    print("Finding files...")
    a = time.time()
    file_objects = fileInfo.create_file_data(dir_to_check)
    b = time.time()
    print("File content hashed. Took {} seconds, {} seconds per file. Writing to database...\n".format(
        b-a, (b-a)/len(file_objects)))

    a = time.time()
    db.write_file_info(file_objects)
    b = time.time()

    print("File data written to database: {}. Took {} seconds.\n".format(db.name, b-a))

    i = input("Search for duplicate files [0]\nExit Program[1]\n")
    if i == "0":
        print("Refining duplicate search by content hash...")
        a = time.time()
        db.duplicate_check()
        b = time.time()
        print("Search refined by content hash. Took {} seconds. {} seconds per file.\n".format(
            b-a, (b-a)/len(file_objects)))

        print("Search complete. {} duplicates found.".format(db.get_duplicate_count()))

    db.close()

    input("Press enter to close the program.")


if __name__ == '__main__':
    main()
