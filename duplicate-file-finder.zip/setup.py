import cx_Freeze

executables = [cx_Freeze.Executable(script="executer.py",
                                    targetName="DuplicateFileFinder.exe")]
include_files = ["dbManager.py", "fileInfo.py", "main.py", "db"]
packages = ["time", "sqlite3", "os", "imohash"]
excludes = ["tkinter"]

cx_Freeze.setup(
    name="DuplicateFileFinder",
    options={
        "build_exe": {
            "packages": packages,
            "include_files": include_files,
            "excludes": excludes
        }
    },
    executables=executables
)
