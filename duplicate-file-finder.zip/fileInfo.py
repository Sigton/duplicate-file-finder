import os
import imohash
import time


SEND_OUTPUT_MESSAGES = True
FILE_FIND_OUTPUT_FREQ = 2000
FILE_READ_BUFFER_SIZE = 65536


class FileData:

    content = None

    def __init__(self, file_id, name, size, path, modified_date=0.0):

        self.file_id = int(file_id)
        self.name = str(name)
        self.size = int(size)
        self.path = str(path)
        self.modified_date = float(modified_date)

    def hash_content(self):
        self.content = imohash.hashfile(self.path)  # hash_content(self.path)


def hash_content(path):

    return imohash.hashfile(path)


def index_directory(path, output_arr):

    items = os.listdir(path)
    for item in items:
        try:
            new_path = os.path.join(path, item)
            if os.path.isdir(new_path):
                index_directory(new_path, output_arr)
            else:
                output_arr.append(FileData(len(output_arr), item, os.path.getsize(new_path),
                                           new_path, os.path.getmtime(new_path)))
                if SEND_OUTPUT_MESSAGES:
                    if len(output_arr) % FILE_FIND_OUTPUT_FREQ == 0:
                        print("Files found: {}.".format(str(len(output_arr))))
        except PermissionError:
            continue


def create_file_data(directory):

    file_data_arr = []

    index_directory(directory, file_data_arr)

    print("{} files found. Hashing file content...".format(len(file_data_arr)))
    [file.hash_content() for file in file_data_arr]

    return file_data_arr
